import { Injectable } from '@angular/core';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class UsersService {

  loadStates(): string[] {
    return ['KAR', 'TN', 'DL', 'MH']
  }
  addUserToDB(data: any) {
    localStorage.setItem('user',JSON.stringify(data))
    this.route.navigateByUrl('/login')


  }
  userLogin(login:any){
    console.log(login);
    localStorage.setItem('user',JSON.stringify(login))
    
  }
  constructor(private route:Router) { }
}
