import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { UsersService } from '../../shared/services/users.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrl: './register.component.css'
})
export class RegisterComponent implements OnInit {

  addUser(nf: NgForm) {
    this.service.addUserToDB(nf.value)
    

  }
  states: any = []
  constructor(private service: UsersService) {

  }
  ngOnInit(): void {
    this.states = this.service.loadStates()
  }
}
