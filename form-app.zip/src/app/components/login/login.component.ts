import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { UsersService } from '../../shared/services/users.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrl: './login.component.css',
})
export class LoginComponent {
  empForm: FormGroup;
  login() {
    this.service.userLogin(this.empForm.value);
  }

  states: any = [];
  constructor(private service: UsersService, private fb: FormBuilder) {
    this.empForm = this.fb.group({
      uname: ['', [Validators.required]],
      password: ['', [Validators.required]],
    });
  }
}
