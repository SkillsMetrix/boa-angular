import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { UsersService } from '../../shared/services/users.service';

@Component({
  selector: 'app-employee',
  templateUrl: './employee.component.html',
  styleUrl: './employee.component.css'
})
export class EmployeeComponent implements OnInit {

  empForm: FormGroup
  addUser() {
    console.log(this.empForm.value);


  }
  states: any = []
  constructor(private service: UsersService, private fb: FormBuilder) {
    this.empForm = this.fb.group({
      uname: ['', [Validators.required]],
      password: ['', [Validators.required, Validators.minLength(6)]],
      email: ['', [Validators.required, this.emailDomainValidator]],
      city: '',
      state: ''
    })

  }
  ngOnInit(): void {
    this.states = this.service.loadStates()
  }
  emailDomainValidator(control: FormControl) {
    let email = control.value
    if (email && email.indexOf('@') != -1) {
      let [before, after] = email.split('@')
      if (after !== 'boa.com') {
        return {
          emailDomain: {
            mydomain: after
          }
        }
      }
    }
    return null
  }
}
