import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { MainappComponent } from './components/mainapp/mainapp.component';
import { HeaderComponent } from './components/header/header.component';
import { FooterComponent } from './components/footer/footer.component';
 
@NgModule({
  // it contains components/directives and pipes
  declarations: [
    AppComponent,
    MainappComponent,
    HeaderComponent,
    FooterComponent,
 
  ],
  // contains modules
  imports: [
    BrowserModule,
    AppRoutingModule
  ],
  // contains services
  providers: [],
  // contains launching component
  bootstrap: [AppComponent]
})
export class AppModule { }
