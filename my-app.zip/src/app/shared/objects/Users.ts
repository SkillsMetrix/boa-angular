

export interface Users{
    uname:string,
    email:string,
    income:number
}