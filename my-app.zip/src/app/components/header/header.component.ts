import { Component } from '@angular/core';
import { UsersService } from '../../shared/services/users.service';
import { Users } from '../../shared/objects/Users';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrl: './header.component.css',
  
})
export class HeaderComponent {

  myname = 'amarjeet'
  mycity = 'pune'

  users: string[] = []
  userdata:Users[]=[]
  // injecting the service in components
  constructor(private us: UsersService) {
    this.users = this.us.loadUsers()
    this.userdata=this.us.loadUserObj()
  }

}
