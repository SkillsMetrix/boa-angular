import { Injectable } from '@angular/core';
import { Users } from '../objects/Users';

@Injectable({
  providedIn: 'root'
})
export class UsersService {

  loadUsers(): string[] {
    return ['admin', 'manager', 'qa']
  }
  loadUserObj(): Users[] {
    return [
      { uname: 'mohan', email: "mohan@mail.com", income: 2345 },
      { uname: 'shivam', email: "shivam@mail.com", income: 3345 },
    ]
  }

}
