import { Component, Input } from '@angular/core';
import { UsersService } from '../../shared/services/users.service';
import { Users } from '../../shared/objects/Users';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrl: './header.component.css',

})
export class HeaderComponent {

  myname = 'amarjeet'
  @Input()
  mycity = 'pune'
  profilePic = 'https://i.pinimg.com/236x/db/1f/9a/db1f9a3eaca4758faae5f83947fa807c.jpg'
  users: string[] = []
  userdata: Users[] = []
  addUser() {
    console.log('user is added');

  }
  // injecting the service in components
  constructor(private us: UsersService) {
    this.users = this.us.loadUsers()
    this.userdata = this.us.loadUserObj()
  }

  people: any[] = [
    {
      "name": 'User-1',
      "country": "USA"
    },
    {
      "name": 'User-2',
      "country": "UK"
    },
    {
      "name": 'User-3',
      "country": "INDIA"
    },
  ]

  getColor(country: string) {
    switch (country) {
      case 'UK':
        return 'green'
      case 'USA':
        return 'blue'
      case 'INDIA':
        return 'purple'
      default:
        return country
    }
  }

}
