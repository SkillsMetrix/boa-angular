import { Component, OnInit } from '@angular/core';
import { AuthService } from '../../auth.service';

@Component({
  selector: 'app-protected',
  templateUrl: './protected.component.html',
  styleUrl: './protected.component.css'
})
export class ProtectedComponent implements OnInit{
data:any
  constructor(private authService:AuthService){}
ngOnInit(): void {
    this.authService.getProtectedData().subscribe({
      next:(res)=> this.data=res,
      error:() => this.authService.logout()
    })
}
logout(){
  this.authService.logout()
}

}
